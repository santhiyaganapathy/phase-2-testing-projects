package gradleproject;

import org.junit.jupiter.api.Test;

public class DemoTest {

	@Test
	public void gradleDemo()
	{
		System.out.println("Gradle demo test..");
		
	}
}
